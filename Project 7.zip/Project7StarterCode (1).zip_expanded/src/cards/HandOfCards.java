package cards;

import cards.PlayingCard;

public interface HandOfCards {
	public void addCard(PlayingCard c);
	public void printHand();
}
