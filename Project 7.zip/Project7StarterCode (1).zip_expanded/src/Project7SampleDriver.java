import java.util.List;
import java.util.Random;

import cards.Deck;
import csc205.*;
import csc205.Sorting;

public class Project7SampleDriver {

		public final static int LENGTH = 30;
		
		public static void main(String[] args) {
			Integer a[] = new Integer[LENGTH];
			
			a = generateRandomArray(LENGTH);

		    // Test sort()
		    System.out.println("Testing sort():");
		    System.out.print("Before sorting: ");
		    printArray(a);
		    Sorting.sort(a);
		    System.out.print("After sorting: ");
		    printArray(a);
		    testSortedArray(a);
		    System.out.println();

		    // test cutoff_qsort
			a = generateRandomArray(LENGTH);
		    System.out.println("Testing cutoff_sort():");
		    System.out.print("Before sorting: ");
		    printArray(a);
		    Sorting.cutoff_qsort(a);
		    System.out.print("After sorting: ");
		    printArray(a);
		    testSortedArray(a);
		    System.out.println();

		    // test cutoff_qsort with cutoff value
			a = generateRandomArray(LENGTH);
		    System.out.println("Testing cutoff_sort():");
		    System.out.print("Before sorting: ");
		    printArray(a);
		    Sorting.cutoff_qsort(a, 5);
		    System.out.print("After sorting: ");
		    printArray(a);
		    testSortedArray(a);
		    System.out.println();

		    // median()
		    System.out.println("\nTesting median()");
			a = generateRandomArray(LENGTH);
			System.out.println("Median a = " + Sorting.median(a));
			Integer m1[] = {10, 5, 15, 4, 14, 3, 13, 2, 12};
			System.out.println("Median m1 = " + Sorting.median(m1));
			Integer m2[] = {5, 15, 4, 14, 3, 13, 2, 12, 10};
			System.out.println("Median m2 = " + Sorting.median(m2));
			Integer m3[] = {2, 4, 6, 8, 10, 12, 14, 16, 18};
			System.out.println("Median m2 = " + Sorting.median(m3));
 /*
		    // first_n() 
		    System.out.println("\nTesting first_n()");
			a = generateRandomArray(LENGTH);
		    System.out.println(Sorting.first_n(a,5));

		    // shuffle()
		    System.out.println("\nTesting shuffle():");
			Deck d = new Deck(52);
			System.out.print("Before sorting: ");
			System.out.println(d);
			d.shuffle();
			System.out.print("After sorting:  ");
			System.out.println(d);
*/
		}
		

		// ----------- Helper functions --------------
		public static void printArray(Object[] a) {
			for (int ii=0;ii<a.length;ii++) {
				System.out.print (a[ii] + " ");
			}
			System.out.println();
		}
		
		public static Integer[] generateRandomArray(int len) {
			Integer[] a = new Integer[len];
			Random rand = new Random();

		    for (int ii=0;ii<a.length;ii++) {
		    	a[ii] = rand.nextInt(1000);
		    }			
		    return a;
		}
		
		public static <T extends Comparable<T>>  
		void testSortedArray(T[] a) {
			if (Sorting.isSorted(a)) {
				System.out.println("The array is sorted!");
			}
			else {
				System.out.println("The array is NOT sorted!");
			}
		}
}

